# TX-only RX self-loopback and Makefile update

## Root cause

`env/top_tb.sv` connects the resolved USB bus back to the DUT receiver:

```systemverilog
assign phy_if.analog_d_plus  = bus_if.bus_dp;
assign phy_if.analog_d_minus = bus_if.bus_dm;
```

That is the correct shared-bus arrangement for external USB peer reception.
However, the old CDR enable assignment was unconditional with respect to local
TX ownership:

```systemverilog
assign phy_if.analog_enable = phy_if.analog_enable_req;
```

The DUT therefore decoded its own transmitted symbols. This is why the TX-only
waveform showed `RX_OUT` bytes matching the TX sequence and why the scoreboard
reported RX valid bytes despite `SLAVE RX BYTES DRIVEN: 0`.

## Correction

The updated top-level uses:

```systemverilog
assign phy_if.analog_enable = phy_if.analog_enable_req &&
                              (tx_rx_loopback_enable || !phy_if.tx_valid);
```

`USB_TX_RX_LOOPBACK` defaults to zero and can be enabled explicitly with
`+USB_TX_RX_LOOPBACK=1`. With the default setting, TX pins remain connected to
the bus for independent TX checking, while the local CDR is squelched during
DUT TX. When the external BFM drives a receive packet, DUT `tx_valid` is low,
so CDR reception remains enabled.

## Makefile updates

- Adds `USB_TX_RX_LOOPBACK` runtime control and includes it in the log filename.
- Adds `tx_regression` for all directed TX tests at LS, FS and HS.
- Adds the directed TX test classes to the full regression list.
- Marks HS RX-only test combinations as `SKIP`, not as DUT failures.
- Uses a new random seed per test/speed when `SEED=random`.
- Checks the final UVM `UVM_ERROR` and `UVM_FATAL` summary counts.
- Rejects unsupported non-RTL modes because this project filelist is RTL-only.

## Validation status

The Makefile syntax and dry-run expansion were checked with GNU Make. Cadence
Xcelium compile and simulation were not run in this environment. Run the
commands in `sim/README.md` on the project machine and inspect the resulting log
and waveform before treating the change as simulation-verified.
