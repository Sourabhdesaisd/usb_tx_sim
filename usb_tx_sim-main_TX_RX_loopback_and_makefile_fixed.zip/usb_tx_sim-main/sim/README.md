# Run with Xcelium

Requires Cadence Xcelium `xrun` with SystemVerilog and UVM 1.2 compatible support and covergroups. From `sim/`:

```sh
make compile
make run TEST=usb_phy_full_path_test USB_SPEED=1
make run TEST=usb_phy_full_path_test USB_SPEED=2
make run TEST=usb_phy_hs_peer_test USB_SPEED=2
make run TEST=usb_phy_fault_test USB_SPEED=0 FAULT=2
make run TEST=usb_phy_reset_test USB_SPEED=1 RESET_CASE=2
make regression
```

`USB_SPEED=0/1/2` selects LS/FS/HS. The HS peer test generates and checks HS line traffic and turnaround; the supplied CDR cannot produce HS RX bytes. `FAULT=1/2/3/4` chooses SE1/missing stuff/long SE0/broken SYNC in the LS/FS RX fault test; the HS peer test generates SE1/stuff/SYNC faults without checking DUT HS RX status. `RESET_CASE=0/1/2` selects initialization/during TX/during RX; RX reset is LS/FS only. `make regression` launches each applicable combination, writing separate `logs/*.log`; the first failure stops the Make target. `make -n regression` prints commands without running. Check UVM_ERROR/UVM_FATAL totals, wire checker packet counters, RX scoreboard checks and actual coverage report before marking results Passed. No simulator was available during creation, so compile and run status is Pending.

The filelist references the included RTL by relative path. Do not mix these files with another version of the same modules; substitute your production RTL in `filelist.f` if needed. Keep WIDTH=8 and 480 MHz defaults unless the TB parameters and timing functions are updated together.

## TX-only tests and RX self-loopback control

The top-level testbench shares the resolved USB bus between the DUT transmitter
and the DUT receiver. That is useful for intentional internal loopback, but it
also means the RX CDR can decode the DUT's own TX packet unless it is squelched.

`env/top_tb.sv` now gates the CDR enable while the DUT transmitter owns the bus:

```systemverilog
assign phy_if.analog_enable = phy_if.analog_enable_req &&
                              (tx_rx_loopback_enable || !phy_if.tx_valid);
```

The default is `USB_TX_RX_LOOPBACK=0`:

- DUT TX remains connected to the shared bus and is checked by the TX wire checker.
- The DUT CDR is disabled while `tx_valid` is high, preventing RX self-decode.
- External USB BFM RX packets are still received when the BFM drives the bus and
  the DUT TX is idle.

To intentionally enable local TX-to-RX loopback, pass `USB_TX_RX_LOOPBACK=1`.

### Run one LS TX test

```bash
cd sim
make run TEST=usb_phy_tx_data_pattern_test USB_SPEED=0 SEED=12345
```

### Run all directed TX tests at LS, FS and HS

```bash
make tx_regression SEED=random
```

### Run the complete supported regression

```bash
make regression SEED=random
```

HS RX-only combinations are recorded as `SKIP`, because the supplied CDR does
not implement HS receive. HS TX tests remain enabled. The Makefile checks the
final UVM `UVM_ERROR` and `UVM_FATAL` summary counts; an xrun exit code of zero
alone is not treated as a passing test.

The current filelist is RTL-only. `MODE=RTL` is accepted; other modes are
rejected rather than silently running the RTL filelist as a gate-level build.
