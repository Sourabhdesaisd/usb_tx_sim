# Randomized TX speed and loopback fixes

## Findings from the supplied Xcelium run

The run completed all four packets. Packets 1 (LS), 2 (FS), and 4 (LS) passed. Packet 3 (HS) had exactly eight symbol mismatches, all in the eight HS EOP symbols: actual `{DP,DM}` was `01`, while the checker expected `00`. The report had `underrun_packets=0` and `timing_errors=0`. Therefore the failure was in the checker EOP model, not FIFO starvation.

## Changes

- Corrected the independent HS TX checker to model the unstuffed NRZ EOP sequence `01111111`. The initial zero causes an NRZI transition to the opposite differential state; the remaining ones hold that state. The expected HS EOP is therefore not SE0. The RTL EOP generator was not changed.
- Added a bounded final RX drain for LS/FS loopback runs so the final RX byte/EOP can reach the monitor and scoreboard before the UVM objection is dropped. HS RX draining is skipped because the supplied `phy_top` does not support HS RX/CDR operation.
- Replaced the enum cast comparison for the reserved speed value with a direct two-bit comparison to avoid the Xcelium enum warning while retaining the speed-switch test fallback.

## Run

From `sim/`:

```bash
make tx_random SEED=12345 TX_RANDOM_PACKETS=4 USB_TX_RX_LOOPBACK=1
```

Expected key results: four TX packets checked, `symbol_errors=0`, `timing_errors=0`, and `packet_failures=0`. The exact speed order and payloads depend on the seed.

The files were reviewed and statically checked in this environment. Xcelium was not available here, so the updated simulation result must be confirmed in the user's Cadence environment.
