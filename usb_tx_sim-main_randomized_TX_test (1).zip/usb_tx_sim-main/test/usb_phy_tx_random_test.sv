// One unified constrained-random USB PHY TX test.
// Speed is selected once by top_tb (USB_SPEED=3 means random LS/FS/HS).
// All packet fields and payload bytes are randomized for every packet.

class usb_phy_tx_rand_packet_cfg extends uvm_object;
  `uvm_object_utils(usb_phy_tx_rand_packet_cfg)

  rand byte unsigned payload[];
  rand int unsigned inter_byte_gap;
  rand bit sof_packet;

  constraint c_payload_size {
    payload.size() inside {[1:64]};
  }

  constraint c_inter_byte_gap {
    inter_byte_gap inside {[0:20]};
  }

  // Encourage data patterns that exercise NRZI and bit stuffing while
  // retaining fully random byte values. No byte value is excluded.
  function new(string name="usb_phy_tx_rand_packet_cfg");
    super.new(name);
  endfunction
endclass

class usb_phy_tx_random_test extends usb_phy_tx_directed_base_test;
  `uvm_component_utils(usb_phy_tx_random_test)

  int unsigned num_packets;
  int unsigned start_symbols;
  int unsigned start_symbol_errors;
  int unsigned start_timing_errors;

  function new(string name="usb_phy_tx_random_test",
               uvm_component parent=null);
    super.new(name,parent);
    num_packets = 100;
  endfunction

  task run_phase(uvm_phase phase);
    usb_phy_tx_rand_packet_cfg rand_cfg;
    byte unsigned packet_bytes[$];
    int unsigned packets_sent;
    bit packet_sof;

    phase.raise_objection(this);
    begin_tx_test();

    if (!$value$plusargs("TX_RANDOM_PACKETS=%d", num_packets))
      num_packets = 100;

    if (num_packets == 0)
      `uvm_fatal("TX_RANDOM", "TX_RANDOM_PACKETS must be greater than zero")

    start_symbols       = env.tx_wire_checker.symbols_checked;
    start_symbol_errors = env.tx_wire_checker.symbol_errors;
    start_timing_errors = env.tx_wire_checker.timing_errors;

    `uvm_info("TX_RANDOM", $sformatf(
      "Starting randomized TX test: speed=%s packets=%0d",
      env_cfg.speed.name(), num_packets), UVM_LOW)

    packets_sent = 0;

    repeat (num_packets) begin
      rand_cfg = usb_phy_tx_rand_packet_cfg::type_id::create(
                   $sformatf("rand_cfg_%0d", packets_sent));

      if (!rand_cfg.randomize())
        `uvm_fatal("TX_RANDOM", "Random packet configuration failed")

      // SOF-specific EOP is supported only for HS in this project.
      packet_sof = (env_cfg.speed == HS) ? rand_cfg.sof_packet : 1'b0;

      packet_bytes.delete();
      foreach (rand_cfg.payload[i])
        packet_bytes.push_back(rand_cfg.payload[i]);

      `uvm_info("TX_RANDOM_PACKET", $sformatf(
        "Packet=%0d speed=%s length=%0d gap=%0d SOF=%0b",
        packets_sent, env_cfg.speed.name(), packet_bytes.size(),
        rand_cfg.inter_byte_gap, packet_sof), UVM_MEDIUM)

      send_packet(packet_bytes, packet_sof, rand_cfg.inter_byte_gap);
      packets_sent++;
    end

    end_tx_test(num_packets, "randomized TX packets");

    if (env.tx_wire_checker.symbol_errors != start_symbol_errors)
      `uvm_error("TX_RANDOM", "New physical symbol mismatches detected")

    if (env.tx_wire_checker.timing_errors != start_timing_errors)
      `uvm_error("TX_RANDOM", "New TX timing mismatches detected")

    `uvm_info("TX_RANDOM_SUMMARY", $sformatf(
      "Completed: speed=%s packets_sent=%0d packets_checked=%0d new_symbols_checked=%0d new_symbol_errors=%0d new_timing_errors=%0d",
      env_cfg.speed.name(), packets_sent,
      env.tx_wire_checker.packets_checked-start_checked,
      env.tx_wire_checker.symbols_checked-start_symbols,
      env.tx_wire_checker.symbol_errors-start_symbol_errors,
      env.tx_wire_checker.timing_errors-start_timing_errors), UVM_LOW)

    phase.drop_objection(this);
  endtask
endclass
